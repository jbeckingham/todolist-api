<?php

namespace AppBundle\Controller\Api\v1;

use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Method;
use Symfony\Component\HttpFoundation\Request;
use AppBundle\Entity\Item;
use Symfony\Component\HttpFoundation\Response;

class ItemController extends Controller {

    /**
     * @Route("/api/v1/additem")
     * @Method("POST")
     */

     public function newAction(Request $request) {
        // Get the Query Parameters from the URL
        // We will trust that the input is safe (sanitized)
        $sourceQuery = $request->query->get('source');
        $itemQuery = $request->query->get('item');

        // Create a new empty object
        $item = new Item();
        // Use methods from the Item entity to set the values
        $item->setSource($sourceQuery);
        $item->setItem($itemQuery);

        // Get the Doctrine service and manager
        $em = $this->getDoctrine()->getManager();

        // Add our item to Doctrine so that it can be saved
        $em->persist($item);

        // Save our item
        $em->flush();

        return new Response("Your item was added!");

     }

     /**
      * @Route("/api/v1/item/{id}")
      * @Method("GET")
      * @param $id
      * @return Response
      */
     public function getAction($id){
        $item = $this->getDoctrine()
        ->getRepository('AppBundle:Item')
        ->findOneBy(['id' => $id]);

        $data = [
            'item' => $item->getItem(),
            'source' => $item->getSource(),
        ];

        return new Response(json_encode($data));
     }

    /**
      * @Route("/api/v1/allitems")
      * @Method("GET")
      * @return Response
      */

      public function getAllAction() {
        $items = $this->getDoctrine()
        ->getRepository('AppBundle:Item')
        ->findAll();

        foreach ($items as $item) {
            $data[] = array(
                'id' => $item->getId(),
                'item' => $item->getItem(),
                'source' => $item->getSource());
        }

        return new Response(json_encode($data));
     }

    /**
      * @Route("/api/v1/updateitem")
      * @Method("POST")
      */

     public function setAction(Request $request) {
        // Get the Query Parameters from the URL
        // We will trust that the input is safe (sanitized)
        $idQuery = $request->query->get('id');
        $itemQuery = $request->query->get('updateitem');

        $item = $this->getDoctrine()
        ->getRepository('AppBundle:Item')
        ->findOneBy(['id' => $idQuery]);

        $item->setItem($itemQuery);
        $em = $this->getDoctrine()->getManager();
        $em->persist($item);
        $em->flush();

        return new Response("You have updated item with id $idQuery");
     }

    /**
     * @Route("/api/v1/deleteitem/{id}")
     * @Method("POST")
     */

    public function deleteAction($id)
    {
        $item = $this->getDoctrine()->getRepository('AppBundle:Item')->find($id);
        $em = $this->getDoctrine()->getManager();
        $em->remove($item);
        $em->flush();

        return new Response("You have successfully removed item with id $id");
    }
}